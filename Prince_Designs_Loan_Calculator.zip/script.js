function calculateEMI() {
  const P = parseFloat(document.getElementById('amount').value) - parseFloat(document.getElementById('downpayment').value || 0);
  const R = parseFloat(document.getElementById('interest').value) / 12 / 100;
  const N = parseInt(document.getElementById('tenure').value);
  const fee = parseFloat(document.getElementById('processing').value || 0);

  const EMI = (P * R * Math.pow(1 + R, N)) / (Math.pow(1 + R, N) - 1);
  const dailyEMI = EMI / 30;
  const totalPayable = (EMI * N) + fee;

  if (isFinite(EMI)) {
    document.getElementById('result').innerHTML = `
      <p><strong>Monthly EMI:</strong> ₹${EMI.toFixed(2)}</p>
      <p><strong>Approx. Daily EMI:</strong> ₹${dailyEMI.toFixed(2)}</p>
      <p><strong>Total Payable Amount:</strong> ₹${totalPayable.toFixed(2)}</p>
    `;
  } else {
    document.getElementById('result').innerText = 'Please enter valid values.';
  }
}
